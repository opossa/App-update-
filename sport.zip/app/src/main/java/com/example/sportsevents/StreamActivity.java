package com.example.sportsevents;

import android.content.pm.ActivityInfo;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.exoplayer2.ui.PlayerView;

public class StreamActivity extends AppCompatActivity {

    private VideoPlayerHelper videoPlayerHelper;
    private PlayerView playerView;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupWindow();
        setContentView(R.layout.activity_stream);
        
        if (getResources().getBoolean(R.bool.portrait_only)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }

        initializeViews();
        checkNetworkConnection();
        hideSystemUI();
    }

    private void setupWindow() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
            layoutParams.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(layoutParams);
        }
    }

    private void initializeViews() {
        playerView = findViewById(R.id.player_view);
        progressBar = findViewById(R.id.progress_bar);
        videoPlayerHelper = new VideoPlayerHelper(this, playerView);
    }

    private void checkNetworkConnection() {
        if (!isNetworkAvailable()) {
            showErrorView("ไม่มีสัญญาณอินเทอร์เน็ต");
            return;
        }
        
        String streamUrl = getIntent().getStringExtra("STREAM_URL");
        if (streamUrl != null && !streamUrl.isEmpty()) {
            startStreaming(streamUrl);
        } else {
            showErrorView("ไม่พบ URL สตรีม");
        }
    }

    private void startStreaming(String streamUrl) {
        showLoading(true);
        String title = getIntent().getStringExtra("STREAM_TITLE");
        videoPlayerHelper.playStream(streamUrl);
        showLoading(false);
    }

    private void showLoading(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        playerView.setVisibility(show ? View.GONE : View.VISIBLE);
    }

    private void showErrorView(String message) {
        playerView.setVisibility(View.GONE);
        progressBar.setVisibility(View.GONE);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (videoPlayerHelper != null) {
            videoPlayerHelper.pausePlayer();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (videoPlayerHelper != null) {
            videoPlayerHelper.resumePlayer();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (videoPlayerHelper != null) {
            videoPlayerHelper.releasePlayer();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}