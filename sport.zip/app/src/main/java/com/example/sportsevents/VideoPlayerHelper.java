package com.example.sportsevents;

import android.content.Context;
import android.net.Uri;
import android.view.ViewGroup;

import com.google.android.exoplayer2.C;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource;
import com.google.android.exoplayer2.upstream.HttpDataSource;

import com.google.android.exoplayer2.source.hls.HlsMediaSource;

import java.util.HashMap;
import java.util.Map;

public class VideoPlayerHelper {
    private SimpleExoPlayer player;
    private PlayerView playerView;
    private Context context;
    private String userAgent = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36";
    private String referer = "https://dookeela2.live/";
    private String currentStreamUrl;

    public VideoPlayerHelper(Context context, PlayerView playerView) {
        this.context = context;
        this.playerView = playerView;
        initializePlayer();
    }

    private void initializePlayer() {
        player = new SimpleExoPlayer.Builder(context).build();
        playerView.setPlayer(player);
        
        player.setHandleAudioBecomingNoisy(true);
        player.setWakeMode(C.WAKE_MODE_NETWORK);
        
        player.addListener(new Player.Listener() {
            @Override
            public void onPlayerError(com.google.android.exoplayer2.PlaybackException error) {
                error.printStackTrace();
                if (currentStreamUrl != null) {
                    playStream(currentStreamUrl);
                }
            }

            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_ENDED) {
                    if (currentStreamUrl != null) {
                        playStream(currentStreamUrl);
                    }
                }
            }
        });
    }

    public void playStream(String streamUrl) {
        currentStreamUrl = streamUrl;
        
        if (player == null) {
            initializePlayer();
        } else {
            player.stop();
        }

        HttpDataSource.Factory dataSourceFactory = new DefaultHttpDataSource.Factory()
                .setUserAgent(userAgent)
                .setDefaultRequestProperties(getRequestHeaders());

        MediaItem mediaItem = new MediaItem.Builder()
                .setUri(Uri.parse(streamUrl))
                .setLiveConfiguration(
                    new MediaItem.LiveConfiguration.Builder()
                        .setMaxPlaybackSpeed(1.02f)
                        .build()
                )
                .build();

        MediaSource mediaSource = new HlsMediaSource.Factory(dataSourceFactory)
                .createMediaSource(mediaItem);

        player.setMediaSource(mediaSource);
        player.prepare();
        player.setPlayWhenReady(true);
        
        player.setPlaybackParameters(
            new PlaybackParameters(1f, 1f)
        );
    }
    
    private Map<String, String> getRequestHeaders() {
        Map<String, String> headers = new HashMap<>();
        headers.put("Referer", referer);
        headers.put("User-Agent", userAgent);
        headers.put("Origin", "https://dookeela2.live");
        headers.put("Accept", "*/*");
        headers.put("Connection", "keep-alive");
        headers.put("Cache-Control", "no-cache");
        return headers;
    }

    public void releasePlayer() {
        if (player != null) {
            player.release();
            player = null;
            currentStreamUrl = null;
        }
    }

    public void pausePlayer() {
        if (player != null) {
            player.setPlayWhenReady(false);
        }
    }

    public void resumePlayer() {
        if (player != null && currentStreamUrl != null) {
            if (player.getPlaybackState() == Player.STATE_ENDED) {
                playStream(currentStreamUrl);
            } else {
                player.setPlayWhenReady(true);
            }
        }
    }

    public boolean isPlaying() {
        return player != null && player.isPlaying();
    }

    public long getCurrentPosition() {
        return player != null ? player.getCurrentPosition() : 0;
    }

    public void seekTo(long position) {
        if (player != null) {
            player.seekTo(position);
        }
    }
    
    public boolean isLive() {
        return player != null && player.isCurrentWindowDynamic();
    }
    
    public long getDuration() {
        return player != null ? player.getDuration() : C.TIME_UNSET;
    }
    
    public long getBufferedPosition() {
        return player != null ? player.getBufferedPosition() : 0;
    }
}