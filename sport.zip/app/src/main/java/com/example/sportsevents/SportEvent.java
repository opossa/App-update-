package com.example.sportsevents;

public class SportEvent {
    private String id;
    private String title;
    private String league;
    private String timeStatus;
    private String team1;
    private String team2;
    private String score;
    private String leagueImageUrl;
    private String team1ImageUrl;
    private String team2ImageUrl;
    private String streamUrl;
    private boolean isLive;

    public SportEvent(String id, String title, String league, String timeStatus,
                     String team1, String team2, String score,
                     String leagueImageUrl, String team1ImageUrl, String team2ImageUrl,
                     String streamUrl, boolean isLive) {
        this.id = id;
        this.title = title;
        this.league = league;
        this.timeStatus = timeStatus;
        this.team1 = team1;
        this.team2 = team2;
        this.score = score;
        this.leagueImageUrl = leagueImageUrl;
        this.team1ImageUrl = team1ImageUrl;
        this.team2ImageUrl = team2ImageUrl;
        this.streamUrl = streamUrl;
        this.isLive = isLive;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getLeague() { return league; }
    public String getTimeStatus() { return timeStatus; }
    public String getTeam1() { return team1; }
    public String getTeam2() { return team2; }
    public String getScore() { return score; }
    public String getLeagueImageUrl() { return leagueImageUrl; }
    public String getTeam1ImageUrl() { return team1ImageUrl; }
    public String getTeam2ImageUrl() { return team2ImageUrl; }
    public String getStreamUrl() { return streamUrl; }
    public boolean isLive() { return isLive; }

    public void setId(String id) { this.id = id; }
    public void setTitle(String title) { this.title = title; }
    public void setLeague(String league) { this.league = league; }
    public void setTimeStatus(String timeStatus) { this.timeStatus = timeStatus; }
    public void setTeam1(String team1) { this.team1 = team1; }
    public void setTeam2(String team2) { this.team2 = team2; }
    public void setScore(String score) { this.score = score; }
    public void setLeagueImageUrl(String leagueImageUrl) { this.leagueImageUrl = leagueImageUrl; }
    public void setTeam1ImageUrl(String team1ImageUrl) { this.team1ImageUrl = team1ImageUrl; }
    public void setTeam2ImageUrl(String team2ImageUrl) { this.team2ImageUrl = team2ImageUrl; }
    public void setStreamUrl(String streamUrl) { this.streamUrl = streamUrl; }
    public void setLive(boolean live) { isLive = live; }
}