package com.example.sportsevents;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private SportEventAdapter adapter;
    private List<SportEvent> eventList = new ArrayList<>();
    private ProgressBar progressBar;
    private static final String WEBSITE_URL = "https://dookeela2.live";
    
    private Handler handler = new Handler();
    private Runnable refreshRunnable = new Runnable() {
        @Override
        public void run() {
            fetchDataFromWebsite();
            handler.postDelayed(this, 60000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        progressBar = findViewById(R.id.progressBar);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SportEventAdapter(eventList, this);
        recyclerView.setAdapter(adapter);

        fetchDataFromWebsite();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.postDelayed(refreshRunnable, 60000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(refreshRunnable);
    }

    private void fetchDataFromWebsite() {
        progressBar.setVisibility(View.VISIBLE);
        
        StringRequest stringRequest = new StringRequest(Request.Method.GET, WEBSITE_URL,
                response -> {
                    parseHtmlData(response);
                    progressBar.setVisibility(View.GONE);
                },
                error -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(MainActivity.this, 
                            "เกิดข้อผิดพลาดในการดึงข้อมูล", 
                            Toast.LENGTH_SHORT).show();
                });

        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void parseHtmlData(String html) {
    new Thread(() -> {
        try {
            List<SportEvent> tempList = new ArrayList<>();
            Document doc = Jsoup.parse(html);
            
            Elements otherSportsSection = doc.select("div.box:has(h1:contains(กีฬาอื่น ๆ))");
            if (!otherSportsSection.isEmpty()) {
                tempList.add(createHeader("กีฬาอื่น ๆ", null));
                
                Elements matches = otherSportsSection.first().select("div.match");
                
                for (Element match : matches) {
                    String title = match.select("div.name").text();
                    boolean isLive = !match.select("small.live").isEmpty();
                    String streamUrl = extractStreamUrl(match.attr("onclick"));
                    
                    String timeInfo = "";
                    if (!isLive) {
                        Elements timeElement = match.select("small:not(.live)");
                        if (!timeElement.isEmpty()) {
                            timeInfo = timeElement.text()
                                .replace("\n", " ")
                                .replace("  ", " ");
                        }
                    }
                    
                    tempList.add(new SportEvent(
                        "event_" + System.currentTimeMillis(),
                        title,
                        "กีฬาอื่น ๆ",
                        isLive ? "สด" : timeInfo,
                        null, null, null, null, null, null,
                        streamUrl,
                        isLive
                    ));
                }
            }

                Elements footballSections = doc.select("div.box:has(h1:containsOwn(-))");
                for (Element section : footballSections) {
                    String leagueTitle = section.select("h1").text();
                    String leagueImage = section.select("img").attr("src");
                    
                    if (leagueImage != null && !leagueImage.startsWith("http")) {
                        leagueImage = "https:" + leagueImage;
                    }
                    
                    tempList.add(createHeader(leagueTitle, leagueImage));
                    
                    Elements matches = section.select("div.match");
                    for (Element match : matches) {
                        String team1 = match.select("div.team-name-left div.name").text();
                        String team2 = match.select("div.team-name-right div.name").text();
                        String score = match.select("div.vs").text();
                        boolean isLive = match.select("small.live").size() > 0;
                        String timeStatus = isLive ? "สด" : match.select("small").text();
                        String streamUrl = extractStreamUrl(match.attr("onclick"));
                        
                        String team1Image = match.select("div.team-name-left img").attr("src");
                        if (team1Image != null && !team1Image.startsWith("http")) {
                            team1Image = "https:" + team1Image;
                        }
                        
                        String team2Image = match.select("div.team-name-right img").attr("src");
                        if (team2Image != null && !team2Image.startsWith("http")) {
                            team2Image = "https:" + team2Image;
                        }
                        
                        tempList.add(new SportEvent(
                                "match_" + System.currentTimeMillis(),
                                null, 
                                leagueTitle,
                                timeStatus,
                                team1,
                                team2,
                                score,
                                leagueImage, 
                                team1Image, 
                                team2Image, 
                                streamUrl,
                                isLive
                        ));
                    }
                }
                
                runOnUiThread(() -> {
                    eventList.clear();
                    eventList.addAll(tempList);
                    adapter.notifyDataSetChanged();
                });
                
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(MainActivity.this, 
                            "เกิดข้อผิดพลาดในการประมวลผลข้อมูล", 
                            Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    private SportEvent createHeader(String title, String leagueImageUrl) {
        return new SportEvent(
                "header_" + System.currentTimeMillis(),
                title,
                null, 
                null, 
                null, 
                null, 
                null, 
                leagueImageUrl, 
                null, 
                null, 
                null, 
                false 
        );
    }

    private String extractStreamUrl(String onclickAttr) {
        if (onclickAttr != null && onclickAttr.startsWith("gotoURL('")) {
            return onclickAttr.replace("gotoURL('", "").replace("')", "");
        }
        return WEBSITE_URL; 
    }
}