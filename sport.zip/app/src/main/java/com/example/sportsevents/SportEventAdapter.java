package com.example.sportsevents;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class SportEventAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int TYPE_HEADER = 0;
    private static final int TYPE_EVENT = 1;
    private static final int TYPE_FOOTBALL_MATCH = 2;

    private final List<SportEvent> events;
    private final WeakReference<Context> contextRef;
    private final OkHttpClient client = new OkHttpClient();
    private int clickedPosition = -1;

    public SportEventAdapter(List<SportEvent> events, Context context) {
        this.events = events;
        this.contextRef = new WeakReference<>(context);
    }

    @Override
    public int getItemViewType(int position) {
        SportEvent event = events.get(position);
        if (isHeader(event)) {
            return TYPE_HEADER;
        } else if (isFootballMatch(event)) {
            return TYPE_FOOTBALL_MATCH;
        } else {
            return TYPE_EVENT;
        }
    }

    private boolean isHeader(SportEvent event) {
        return event.getLeague() == null 
                && event.getTitle() != null 
                && event.getTeam1() == null 
                && event.getTeam2() == null;
    }

    private boolean isFootballMatch(SportEvent event) {
        return event.getTeam1() != null && event.getTeam2() != null;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        switch (viewType) {
            case TYPE_HEADER:
                return new HeaderViewHolder(inflater.inflate(R.layout.item_header, parent, false));
            case TYPE_FOOTBALL_MATCH:
                return new FootballMatchViewHolder(inflater.inflate(R.layout.item_football_match, parent, false));
            default:
                return new EventViewHolder(inflater.inflate(R.layout.item_event, parent, false));
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        SportEvent event = events.get(position);
        Context context = contextRef.get();
        if (context == null) return;

        switch (holder.getItemViewType()) {
            case TYPE_HEADER:
                bindHeader((HeaderViewHolder) holder, event, context);
                break;
            case TYPE_FOOTBALL_MATCH:
                bindFootballMatch((FootballMatchViewHolder) holder, event, context, position);
                break;
            default:
                bindEvent((EventViewHolder) holder, event, context, position);
        }
    }

    private void bindHeader(HeaderViewHolder holder, SportEvent event, Context context) {
        holder.headerTitle.setText(event.getTitle());
        
        if (event.getLeagueImageUrl() != null && !event.getLeagueImageUrl().isEmpty()) {
            Glide.with(context)
                    .load(event.getLeagueImageUrl())
                    .placeholder(android.R.drawable.ic_menu_report_image)
                    .error(android.R.drawable.ic_menu_close_clear_cancel)
                    .into(holder.leagueLogo);
        }

        holder.itemView.setOnClickListener(v -> handleItemClick(event));
    }

    private void bindFootballMatch(FootballMatchViewHolder holder, SportEvent event, Context context, int position) {
        holder.team1Name.setText(event.getTeam1());
        holder.team2Name.setText(event.getTeam2());
        holder.score.setText(event.getScore());
        holder.timeStatus.setText(event.getTimeStatus());

        updateLiveStatus(holder.liveBadge, holder.timeStatus, event.isLive());

        loadImage(holder.team1Logo, event.getTeam1ImageUrl(), context);
        loadImage(holder.team2Logo, event.getTeam2ImageUrl(), context);

        holder.itemView.setOnClickListener(v -> {
            clickedPosition = position;
            handleItemClick(event);
        });

        setupFocusAnimation(holder.itemView);
    }

    private void bindEvent(EventViewHolder holder, SportEvent event, Context context, int position) {
        holder.eventTitle.setText(event.getTitle());
        updateLiveStatus(holder.liveBadge, holder.timeStatus, event.isLive());
        
        if (!event.isLive()) {
            holder.timeStatus.setText(event.getTimeStatus());
        }

        holder.itemView.setOnClickListener(v -> {
            clickedPosition = position;
            handleItemClick(event);
        });

        setupFocusAnimation(holder.itemView);
    }

    private void updateLiveStatus(View liveBadge, View timeStatus, boolean isLive) {
        liveBadge.setVisibility(isLive ? View.VISIBLE : View.GONE);
        timeStatus.setVisibility(isLive ? View.GONE : View.VISIBLE);
    }

    private void loadImage(ImageView imageView, String imageUrl, Context context) {
        if (imageUrl != null && !imageUrl.isEmpty()) {
            Glide.with(context)
                    .load(imageUrl)
                    .placeholder(android.R.drawable.ic_menu_gallery)
                    .error(android.R.drawable.ic_menu_close_clear_cancel)
                    .into(imageView);
        }
    }

    private void setupFocusAnimation(View view) {
        view.setOnFocusChangeListener((v, hasFocus) -> {
            float scale = hasFocus ? 1.05f : 1f;
            v.animate().scaleX(scale).scaleY(scale).setDuration(150).start();
        });
    }

    private void handleItemClick(SportEvent event) {
        if (event.getStreamUrl() != null) {
            extractChannelId(event.getStreamUrl());
        } else {
            showToast("ไม่มีลิงก์สตรีม");
        }
    }

    private void extractChannelId(String url) {
        if (url == null || url.isEmpty()) {
            showToast("URL ไม่ถูกต้อง");
            return;
        }

        Request request = new Request.Builder().url(url).build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                showToast("เชื่อมต่อล้มเหลว");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    showToast("เซิร์ฟเวอร์ผิดปกติ: " + response.code());
                    return;
                }

                String html = response.body().string();
                Pattern pattern = Pattern.compile("get_license\\('([^']+)'\\)");
                Matcher matcher = pattern.matcher(html);

                if (matcher.find()) {
                    getLicenseAndPlay(matcher.group(1));
                } else {
                    showToast("ไม่พบ Channel ID");
                }
            }
        });
    }

    private void getLicenseAndPlay(String channel) {
        HttpUrl url = new HttpUrl.Builder()
                .scheme("https")
                .host("licensekey.dookeela2.live")
                .addQueryParameter("app", "dookeela")
                .addQueryParameter("channel", channel)
                .build();

        client.newCall(new Request.Builder().url(url).build()).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                showToast("ขอ License ไม่สำเร็จ");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    showToast("License Server Error: " + response.code());
                    return;
                }

                String licenseKey = response.body().string().trim();
                String streamUrl = "https://streamamg-fa.akamaiz.com/dookeela/" + 
                                 channel + "/playlist.m3u8?wmsAuthSign=" + licenseKey;
                runOnUiThread(() -> playStream(streamUrl));
            }
        });
    }

    private void playStream(String streamUrl) {
        Context context = contextRef.get();
        if (context == null || clickedPosition < 0 || clickedPosition >= events.size()) return;

        SportEvent event = events.get(clickedPosition);
        String cleanUrl = streamUrl.replace("{\"license\":\"", "").replace("\"}", "");

        Intent intent = new Intent(context, StreamActivity.class)
                .putExtra("STREAM_URL", cleanUrl)
                .putExtra("STREAM_TITLE", getStreamTitle(event));

        context.startActivity(intent);
    }

    private String getStreamTitle(SportEvent event) {
        if (event.getTitle() != null) {
            return event.getTitle();
        } else if (event.getTeam1() != null && event.getTeam2() != null) {
            return event.getTeam1() + " vs " + event.getTeam2();
        }
        return "รายการสด";
    }

    private void showToast(String message) {
        Context context = contextRef.get();
        if (context instanceof Activity) {
            ((Activity) context).runOnUiThread(() -> 
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show());
        }
    }

    private void runOnUiThread(Runnable action) {
        Context context = contextRef.get();
        if (context instanceof Activity) {
            ((Activity) context).runOnUiThread(action);
        }
    }

    @Override
    public int getItemCount() {
        return events.size();
    }

    public static class HeaderViewHolder extends RecyclerView.ViewHolder {
        TextView headerTitle;
        ImageView leagueLogo;

        public HeaderViewHolder(@NonNull View itemView) {
            super(itemView);
            headerTitle = itemView.findViewById(R.id.headerTitle);
            leagueLogo = itemView.findViewById(R.id.leagueLogo);
        }
    }

    public static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView eventTitle, liveBadge, timeStatus;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            eventTitle = itemView.findViewById(R.id.eventTitle);
            liveBadge = itemView.findViewById(R.id.liveBadge);
            timeStatus = itemView.findViewById(R.id.timeStatus);
        }
    }

    public static class FootballMatchViewHolder extends RecyclerView.ViewHolder {
        TextView team1Name, team2Name, score, liveBadge, timeStatus;
        ImageView team1Logo, team2Logo;

        public FootballMatchViewHolder(@NonNull View itemView) {
            super(itemView);
            team1Name = itemView.findViewById(R.id.team1Name);
            team2Name = itemView.findViewById(R.id.team2Name);
            score = itemView.findViewById(R.id.score);
            liveBadge = itemView.findViewById(R.id.liveBadge);
            timeStatus = itemView.findViewById(R.id.timeStatus);
            team1Logo = itemView.findViewById(R.id.team1Logo);
            team2Logo = itemView.findViewById(R.id.team2Logo);
        }
    }
}